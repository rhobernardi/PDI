Gabriel Estrela - 8124138

Como executar:

	1 - Extraia todos arquivos para uma pasta
	2 - Navegue ate ela pelo terminal
	3 - Execute: g++ tarefa5.cpp -o filtragem
	4 - Execute: ./filtragem arquivo.pgm media 3 novo_arquivo.pgm
	    		 ./filtragem arquivo.pgm mediana 3 novo_arquivo.pgm
	    		 ./filtragem arquivo.pgm gauss 1 novo_arquivo.pgm 

	OBS: Eh necessario possuir a imagem origem
	     A imagem gerada sera nomeada atraves do comando "./filtragem ..."
	     O nome do arquivo DEVE ter a extensão junta do nome! ex.: “feep.pgm”
	     O programa foi testado em um MACBook PRO (late 2013).
	     Utilize C++11
	     O Ex. 5 ira pedir os comandos como foram determinados na descrição
		 	