#Tarefa 5 - Processamento de Imagem

- Rodrigo das Neves Bernardi - 8066395

Para compilar:

	$ make


Para rodar o programa:

	$ ./filtragem <image_in>.pgm <filter> <mask> <image_out>.pgm
