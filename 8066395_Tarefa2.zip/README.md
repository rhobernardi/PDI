#Tarefa 1 - Processamento de Imagem

Para compilar:

	$ make


Para rodar o programa:
	
	$ make run


Caso queira mudar o nome do arquivo de entrada, abra o Makefile e altere a variavel IN no inicio do Makefile para o nome do arquivo de imagem que desejar