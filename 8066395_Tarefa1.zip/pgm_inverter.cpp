
/*****************************************************************
*
*    SCC0251 - Processamento de Imagem
*    Tarefa 1 - Inversão de tonalidade cinza de uma imagem.
*
*    -Rodrigo Bernardi
*
******************************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>


typedef unsigned char uchar;

typedef struct IMGstructure {
    char type[3];
    int width;
    int height;
    int maxVal;
    uchar *pixel;
} Image;



// aloca memória necessária para uma Image, recebendo suas informações
void allocData(Image *img, char* type, int width, int height, int maxVal) 
{
    strcpy(img->type, type);
    img->width = width;
    img->height = height;
    img->maxVal = maxVal;

    if(img->type[0] == 'P' && img->type[1] == '2') 
    {
        img->pixel = (uchar *)malloc(width * height * sizeof(uchar));
    }
}

// libera memória usada por uma Image
void freeData(Image *img) 
{    
    if (img->type[0] == 'P' && img->type[1] == '2') 
    {
        free(img->pixel);
    }
}

// cria uma estrutura Image, incluindo a leitura do arquivo e a chamada da função para alocar a imagem na memória
void readImage(Image *imgIn, Image *imgOut, char *in) 
{
    FILE *input;
    char type[3];
    int maxVal, width, height;

    input = fopen(in, "r");

    if (input == NULL)
        printf("Can't read image file.\n");
    
    else {
        // le tipo
        rewind(input);
        fscanf(input, "%s", type);

        // compara tipo para ver se é pgm (escala de cinza)
        if(type[0] == 'P' && type[1] == '2') 
        {
            // pula fim da linha
            while (getc(input) != '\n');

            // pula comentario da linha
            while (getc(input) == '#') {
                while (getc(input) != '\n');
            }

            // volta um caracter
            fseek(input, -1, SEEK_CUR);

            // le dimensões da imagem e a escala das cores
            fscanf(input, "%d", &width);
            fscanf(input, "%d", &height);
            fscanf(input, "%d", &maxVal);

            // aloca as matrizes width x height das imagens de entrada e saída na memória
            allocData(imgIn, type, width, height, maxVal);
            allocData(imgOut, type, width, height, maxVal);
            
            // le dados do arquivo
            for(int i = 0; i < width * height ; i++) 
            {
                fscanf(input, "%hhu\n", &(imgIn->pixel[i]));        
            }
        }
    }

    fclose(input);
}

// cria um arquivo com o resultado guardado na matriz de imagem de saída
void saveImage(Image *img, char *out) 
{
    FILE *output;

    // escreve header contendo tipo, comentário, dimensões e escala
    output = fopen(out, "w");
    fprintf(output, "%s\n", img->type);
    fprintf(output, "#imagem gerada pelo programa\n");
    fprintf(output, "%d %d\n", img->width, img->height);
    fprintf(output, "%d\n", img->maxVal);

    // escreve dados da imagem

    if(img->type[0] == 'P' && img->type[1] == '2') {
        for (int i = 0; i < img->height * img->width; i++) 
        {
            fprintf(output, "%hhu\n", img->pixel[i]);
        }
    }

    fclose(output);
}

void processInversion(Image *imgIn, Image *imgOut)
{
    for (int i = 0; i < imgIn->height * imgIn->width; i++) 
    {
        imgOut->pixel[i] = imgIn->pixel[i];
        imgOut->pixel[i] = imgIn->maxVal - imgOut->pixel[i];
    }
}


int main(int argc, char const *argv[]) 
{
    Image imgIn, imgOut;

    uchar *inPixel, *outPixel;
    int size;
    char input[20], output[20];
    double result;

    strcpy(input, argv[1]);
    strcpy(output, "img_out.pgm");

    // le a imagem de entrada
    readImage(&imgIn, &imgOut, input);

    size = imgIn.width * imgIn.height;

    // execucao do programa para imagens em escala de cinza (PGM)
    if (imgIn.type[0] == 'P' && imgIn.type[1] == '2')
    {
        printf("\nInverting tones...\n");
        processInversion(&imgIn, &imgOut);

        // Salva imagem invertida
        saveImage(&imgOut, output);

        freeData(&imgIn);
        freeData(&imgOut);
        printf("Done.\n");
    }

    else printf("== IMAGE IS NOT IN PGM FORMAT (P2 format) ==\n");

    return 0;
}