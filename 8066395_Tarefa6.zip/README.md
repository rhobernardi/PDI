#Tarefa 6 - Processamento de Imagem

- Rodrigo das Neves Bernardi - 8066395

Para compilar, va a pasta onde os arquivos foram unziped e digite o comando:

	$ make


Para rodar o programa:

	$ ./DisplayLines <Image_Path>



Nota: 	Estou utilizando a biblioteca de computação visual OpenCV v3.1.0. 
		A compilação eh dada atraves do programa cmake, porem optimizei o processo para que apenas digitando o comando 'make', o cmake seja chamado e a compilacao seja realizada. Bastara entao digitar a linha de comando de execucao apenas.