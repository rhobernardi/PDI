#Tarefa 4 - Processamento de Imagem

- Rodrigo das Neves Bernardi - 8066395

Para compilar:

	$ make


Para rodar o programa:
	
	$ make run

ou

	$ ./tarefa4 tartaruga.pgm <comando_de_entrada>

Nota: Caso queira mudar o comando para manusear a tartaruga pelo Makefile, abra o Makefile e altere a variavel 'CMD' no inicio do arquivo para que o programa seja executado com o comando desejado. Segue um exemplo:

	CMD = MH +90